from Arduino_Stepper import Arduino_BT_Stepper

stepper_motor = Arduino_BT_Stepper()

stepper_motor.ping()